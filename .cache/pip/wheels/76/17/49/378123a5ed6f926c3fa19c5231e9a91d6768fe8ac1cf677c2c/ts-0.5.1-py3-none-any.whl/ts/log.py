
import logging


lg = logging.getLogger('ts')
requests_lg = logging.getLogger('requests')
