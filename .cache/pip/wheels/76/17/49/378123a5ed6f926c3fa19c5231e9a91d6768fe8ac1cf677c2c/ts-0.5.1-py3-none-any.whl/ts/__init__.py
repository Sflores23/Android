# coding: utf-8

# Use semantic versioning: MAJOR.MINOR.PATCH
__version__ = '0.5.1'
